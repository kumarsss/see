# seedr-kodi

Seedr.cc Official Kodi Plugin.

## Features

- Browse your Seedr.cc Files
- Stream videos with seeking support
- Play your music library

## Installation

Install from Kodi Add-ons repository.
